"/mnt/irisgpfs/apps/resif/aion/2020b/epyc/software/MATLAB/2021a/toolbox/shared/coder/ninja/glnxa64/ninja" -t compdb cc cxx cudac > compile_commands.json
"/mnt/irisgpfs/apps/resif/aion/2020b/epyc/software/MATLAB/2021a/toolbox/shared/coder/ninja/glnxa64/ninja" -v "$@"
